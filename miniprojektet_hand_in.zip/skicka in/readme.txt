You compile the program with the usual "make"-command and then running the "detkv-run main.bin"
In the folder you will need the program-code as well as our modified delayfile.S from lab1 (contains delay). Put the files inte the time4riscv-folder (from lab1) and switch out the boot.S file for our modified with enable_interupt. 
You will also need to be plugged in to a screen through the VGA-port. 

To play the game:
-Button 1 starts a new round. 
-From right to left: 
    -switch 1 = right
    -switch 2 = left
    -switch 3 = down
    -switch 4 = up 

